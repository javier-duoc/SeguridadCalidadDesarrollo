package com.veterinaria.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.veterinaria.demo.jwt.JwtFilter;



@Configuration
@EnableWebSecurity

public class WebSecurityConfig {

    // ------------------------------------------- SEMANA 2 ------------------------------------
    // Cadena 1: aplica solo a /api/** → stateless + JWT
    // JwtFilter se inyecta como parámetro para evitar dependencia circular
    @Bean
    @Order(1)

    public SecurityFilterChain apiFilterChain(HttpSecurity http, JwtFilter jwtFilter) throws Exception {
        http
            .securityMatcher("/api/**")
            .csrf(csrf -> csrf.disable())
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            .authorizeHttpRequests(auth -> auth
                .requestMatchers(HttpMethod.POST, "/api/auth/login").permitAll()
                .anyRequest().authenticated()
            )
            .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

        // Cadena 2: aplica al resto → form login tradicional
    @Bean
    @Order(3)
    public SecurityFilterChain webFilterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(requests -> requests
                .requestMatchers("/", "/home").permitAll()
                .requestMatchers("/**.css").permitAll()
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .permitAll()
            )
            .logout(logout -> logout.permitAll());
        return http.build();
    }
    
    // Necesario para que AuthController pueda autenticar con authManager.authenticate()
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
 @Bean
    @Description("In memory UserDetailsService: los usuarios no se guardan en base de datos")
    public UserDetailsService users() {
        UserDetails admin = User.builder()
                .username("admin")
                .password(passwordEncoder().encode("admin123"))
                .roles("ADMIN")
                .build();

        UserDetails recepcion = User.builder()
                .username("recepcion")
                .password(passwordEncoder().encode("recep123"))
                .roles("RECEPCION")
                .build();

        UserDetails veterinario = User.builder()
                .username("vet")
                .password(passwordEncoder().encode("vet123"))
                .roles("VETERINARIO")
                .build();

        return new InMemoryUserDetailsManager(admin, recepcion, veterinario);
    }
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

//-------------------------------------------------------

           @Bean
             @Order(2)
            public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
            http
            .authorizeHttpRequests(requests -> requests

                // ---------- RUTAS PUBLICAS ----------
                .requestMatchers("/", "/home", "/login", "/acceso-denegado").permitAll()
                .requestMatchers("/css/**", "/js/**", "/images/**").permitAll()

                // TODO ALUMNOS (1 de 2): agregar aqui la regla que hace publica
                // la ruta "/nosotros". Pista: .requestMatchers("/nosotros").permitAll()
                .requestMatchers("/nosotros").permitAll()

                // ---------- PACIENTES (privado) ----------
                // Registrar pacientes: solo ADMIN y RECEPCION
                .requestMatchers("/pacientes/nuevo").hasAnyRole("ADMIN", "RECEPCION")
                .requestMatchers(HttpMethod.POST, "/pacientes").hasAnyRole("ADMIN", "RECEPCION")

                // Eliminar pacientes: solo ADMIN
                .requestMatchers(HttpMethod.POST, "/pacientes/*/eliminar").hasRole("ADMIN")

                // Ver el listado: cualquier usuario autenticado
                .requestMatchers("/pacientes/**").authenticated()

                // ---------- CITAS (privado) ----------
                // Programar citas: solo ADMIN y RECEPCION
                .requestMatchers("/citas/nueva").hasAnyRole("ADMIN", "RECEPCION")
                .requestMatchers(HttpMethod.POST, "/citas").hasAnyRole("ADMIN", "RECEPCION")

                // Cancelar citas: solo ADMIN
                .requestMatchers(HttpMethod.POST, "/citas/*/eliminar").hasRole("ADMIN")
                
                // Ver la agenda: cualquier usuario autenticado
                .requestMatchers("/citas/**").authenticated()

                // ---------- VETERINARIOS (privado) ----------
                // TODO ALUMNOS (2 de 2): agregar aqui la regla que deja "/veterinarios/**"
                // accesible SOLO para el rol ADMIN. Pista: .hasRole("ADMIN")
                .requestMatchers("/veterinarios/**").hasRole("ADMIN")
                
                // ---------- TODO LO DEMAS ----------
                // Cualquier URL no listada arriba exige sesion iniciada.
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .defaultSuccessUrl("/home", true)
                .permitAll()
            )
            .logout(logout -> logout
                .logoutSuccessUrl("/home?logout")
                .permitAll()
            )
            .exceptionHandling(ex -> ex
                .accessDeniedPage("/acceso-denegado")
            );

        return http.build();
        }
}
        


 









 