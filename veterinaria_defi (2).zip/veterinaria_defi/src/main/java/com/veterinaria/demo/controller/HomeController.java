package com.veterinaria.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Rutas publicas del sistema: portada y login.
 */

@Controller
public class HomeController {

    private static final String NOMBRE_APP = "VetCare - Sistema de Gestion Veterinaria";

    @GetMapping({"/", "/home" })
    public String home (Model model) {
        model.addAttribute("name", NOMBRE_APP);
        return "home";
    }

    @GetMapping("/login")
    public String login (Model model) {
        model.addAttribute("name", NOMBRE_APP);
        return "login";
    }

      @GetMapping("/")
    public String root(@RequestParam(name="name", required=false, defaultValue="Seguridad y Calidad en el Desarrollo") String name, Model model) {
    model.addAttribute("name", name);
    return "home";
    }

    /**
     * Pagina mostrada cuando el usuario esta autenticado pero su rol no basta (error 403).
     *
     * Se mapea con @RequestMapping sin indicar el metodo HTTP a proposito: Spring Security
     * hace un "forward" a esta URL conservando el metodo original, asi que un POST denegado
     * (por ejemplo eliminar un paciente sin ser ADMIN) tambien debe poder entrar aqui.
     */

    @RequestMapping("/acceso-denegado")
    public String accesoDenegado() {
        return "acceso-denegado";
    }

      @GetMapping("/nosotros")
    public String nosotros (Model model) {
        model.addAttribute("name", NOMBRE_APP);
        return "nosotros";
    }



// =====================================================================
    // TODO ALUMNOS (1 de 2) - RUTA PUBLICA "/nosotros"
    // ---------------------------------------------------------------------
    // Deben crear la pagina publica "Nosotros" de la veterinaria (horarios,
    // direccion y telefono de contacto). Cualquier visitante debe poder verla
    // SIN iniciar sesion.
    //
    // Pasos:
    //   1. Crear aqui un metodo con @GetMapping("/nosotros") que devuelva
    //      la vista "nosotros".
    //   2. Crear la plantilla src/main/resources/templates/nosotros.html
    //      reutilizando el fragmento de layout (ver home.html como ejemplo).
    //   3. Autorizar la URL en WebSecurityConfig con .requestMatchers(...).permitAll()
    //
    // Como comprobar que quedo bien: abrir http://localhost:8080/nosotros en
    // una ventana de incognito (sin sesion iniciada) y ver la pagina, no el login.
    // =====================================================================
}


